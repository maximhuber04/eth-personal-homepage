
/**
 * A node of a singly-linked list of integer values
 */
public class IntNode {
    
    int value;
    IntNode next;
    
    public IntNode(int value) {
        this.value = value;
    }
}
