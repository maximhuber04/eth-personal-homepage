
public class Matrix {

	static boolean checkMatrix(int [][]m) {
		// TODO: Implementieren Sie die Methode
		return false;
	}
}
