

public class Split57 {
	
	
	public static boolean[] split57(int[] x) {
		// TODO: Implementieren Sie die Methode
		
		return null;
	}

}
