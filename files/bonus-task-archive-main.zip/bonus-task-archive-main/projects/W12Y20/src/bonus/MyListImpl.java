package bonus;

public class MyListImpl<T> implements MyList<T> {

	// TODO: Implementieren Sie die Methoden.
}
