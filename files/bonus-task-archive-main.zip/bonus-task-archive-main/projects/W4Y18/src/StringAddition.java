import java.util.Scanner;

public class StringAddition {
	
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		String s1 = scanner.next();
		String s2 = scanner.next();
		
		String result = add(s1,s2);
		
		System.out.println(result);
    }

	public static String add(String s1, String s2) {
		// TODO Schreiben Sie Ihre Implementation hier
		return null;
	}
}