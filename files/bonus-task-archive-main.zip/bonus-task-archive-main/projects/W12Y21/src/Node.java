
// Aendern Sie diese Datei nicht!

public interface Node {
	/** Stellt dem Knoten die Nachricht 'msg' zu. */
	void receive(Message msg);
}
