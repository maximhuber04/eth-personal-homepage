
// Ausser der "extends" Klausel, veraendern Sie diese Datei nicht!

public class KlasseB /* Wenn noetig, dann fuegen Sie hier eine "extends" Klausel hinzu */ {
    int x = 0;

    int foo() {
        return x;
    }
}