
// Ausser der "extends" Klausel, veraendern Sie diese Datei nicht!

public class KlasseE /* Wenn noetig, dann fuegen Sie hier eine "extends" Klausel hinzu */ {
    boolean foo() {
        return false;
    }
}