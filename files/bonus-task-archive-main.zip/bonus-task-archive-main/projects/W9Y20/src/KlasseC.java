
// Ausser der "extends" Klausel, veraendern Sie diese Datei nicht!

public class KlasseC /* Wenn noetig, dann fuegen Sie hier eine "extends" Klausel hinzu */ {
    int foo() {
        return x+1;
    }
}