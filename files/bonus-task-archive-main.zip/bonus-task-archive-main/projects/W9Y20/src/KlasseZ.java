
// Ausser der "extends" Klausel, veraendern Sie diese Datei nicht!

public class KlasseZ /* Wenn noetig, dann fuegen Sie hier eine "extends" Klausel hinzu */ {
}