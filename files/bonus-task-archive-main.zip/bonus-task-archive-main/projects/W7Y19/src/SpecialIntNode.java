
/**
 * A node of a singly-linked list of integer values
 */
public class SpecialIntNode {
	
	// Aendern Sie diese Klasse nicht.
    
    int value;
    SpecialIntNode next;
    SpecialIntNode oldNext;
    
    public SpecialIntNode(int value) {
        this.value = value;
    }
}
