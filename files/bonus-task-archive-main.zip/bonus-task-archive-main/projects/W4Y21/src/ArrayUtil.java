
public class ArrayUtil {
	
	public static int[] zeroInsert(int[] x) {
		// TODO: Vervollstaendigen Sie den Code wie in der Aufgabenbeschreibung beschrieben
		return null;
	}
	
	public static boolean tenFollows(int[] x, int index) {
		// TODO: Vervollstaendigen Sie den Code wie in der Aufgabenbeschreibung beschrieben
		return false;
	}
}
