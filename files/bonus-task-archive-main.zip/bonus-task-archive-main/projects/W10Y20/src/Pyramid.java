public class Pyramid {
	
	public static boolean isPyramid(Node node) {
		// TODO: Implementieren Sie die Methode    	
		return false;
	}

	public static void main(String[] args) {
		Node pyramid = new Node(
			new Node(null, null),
			new Node(null, null));
        System.out.println("result: " + isPyramid(pyramid));
	}

}
