
public class Ball {
	
}
