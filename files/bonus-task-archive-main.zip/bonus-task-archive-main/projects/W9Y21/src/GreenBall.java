
public class GreenBall extends Ball {
	public GreenBall() {
		
	}
}
