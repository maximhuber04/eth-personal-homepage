
public class RedBall extends Ball {
	public RedBall() {
		
	}
}
