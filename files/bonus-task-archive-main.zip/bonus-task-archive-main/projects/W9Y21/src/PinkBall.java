
public class PinkBall extends Ball {
	public PinkBall() {
		
	}
}