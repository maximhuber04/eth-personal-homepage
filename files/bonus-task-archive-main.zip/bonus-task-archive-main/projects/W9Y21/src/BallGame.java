
public class BallGame {
	
	public BallGame(BallPool pool) {
		
	}

	public int playGame(int turns, int startScore) {
		// TODO		
		
		return 0;
	}
}
