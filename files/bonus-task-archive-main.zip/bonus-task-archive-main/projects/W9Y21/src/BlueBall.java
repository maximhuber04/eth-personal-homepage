
public class BlueBall extends Ball {
	public BlueBall() {
		
	}
}
