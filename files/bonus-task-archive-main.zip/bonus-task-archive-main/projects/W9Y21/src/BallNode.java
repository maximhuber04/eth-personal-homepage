
/**
 * A node of a singly-linked list of Ball values
 */
public class BallNode {
    
    Ball value;
    BallNode next;
    
    public BallNode(Ball value) {
        this.value = value;
    }
}
