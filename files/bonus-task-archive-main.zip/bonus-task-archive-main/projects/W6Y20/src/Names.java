
public class Names {

	public static String[] toGerman(String name) {
		// TODO: Vervollständigen Sie die Methode
		String germanName = null;
		String summary = null;
		return new String[]{germanName, summary};
	}
}
