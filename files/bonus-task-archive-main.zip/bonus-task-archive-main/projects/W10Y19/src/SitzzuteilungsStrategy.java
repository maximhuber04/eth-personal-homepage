
// Veraendern Sie keine der vorhandenen Deklarationen.
// Sie koennen und sollen die Implementationen hinzufuegen.

interface SitzzuteilungStrategy {
	// TODO: Definieren Sie die noetigen Methoden
}

class SitzzuteilungStrategyFactory {
	
	public SitzzuteilungStrategyFactory() {
		// Hier koennen Sie ebenfalls Code hinzufuegen
	}
	
	SitzzuteilungStrategy getSainteLague() {
		// TODO: Geben Sie hier eine Instanz der Sainte-Lague Implementation zurueck.
		// Zur Erinnerung, Sainte-Lague ist ein Hoechstzahl-Verfahren mit der Divisorfolge 0.5, 1.5, 2.5, ...
		return null; // solution
	}
	
	SitzzuteilungStrategy getDHondt() {
		// TODO: Geben Sie hier eine Instanz der D'Hondt Implementation zurueck.
		// Zur Erinnerung, D'Hondt ist ein Hoechstzahl-Verfahren mit der Divisorfolge 1, 2, 3, ...
		return null; // solution
	}
}



