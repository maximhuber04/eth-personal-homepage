
public class FlexArray {

	FlexArray() {
        // TODO
    }

    FlexArray(int size) {
    	// TODO
    }

    FlexArray(int size, int start) {
    	// TODO
    }

    public int length() {
    	// TODO
        return 0;
    }

    public int base() {
    	// TODO
        return 0;
    }

    public int[] rawArray() {
    	// TODO
        return null;
    }

    public int read(int index) {
    	// TODO
    	return 0;
    }

    public void write(int index, int value) {
    	// TODO
    }

    public FlexArray copy() {
    	// TODO
    	return null;
    }

    public FlexArray merge(FlexArray f) {
    	// TODO
    	return null;
    }

    @Override
    public boolean equals(Object o) {
    	// TODO
    	return super.equals(o);

    }
}
