import java.util.List;
import java.util.Scanner;

public class Service {

    public Service(Scanner scanner) {
        // TODO
    }

    public List<Integer> critical(double bound1, double bound2) {
        // TODO
        return null;
    }

    public List<Integer> top(int limit) {
        // TODO
        return null;
    }
}