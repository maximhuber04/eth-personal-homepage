public class SwissTime {

    public static void main(String[] args) {
        // Die Beispiele vom Übungsblatt:
        System.out.println("00:00 -> " + toSwissGerman("00:00"));
        System.out.println("01:45 -> " + toSwissGerman("01:45"));
        System.out.println("09:25 -> " + toSwissGerman("09:25"));
        System.out.println("12:01 -> " + toSwissGerman("12:01"));
        System.out.println("16:46 -> " + toSwissGerman("16:46"));
        System.out.println("21:51 -> " + toSwissGerman("21:51"));
        System.out.println("22:37 -> " + toSwissGerman("22:37"));
    }

    public static String toSwissGerman(String time) {
        // TODO: Fügen Sie hier Ihre Lösung ein. Sie können
        //       auch zusätzliche Methoden hinzufügen.
        return "TODO";
    }
}
