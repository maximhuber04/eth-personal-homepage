public class Student {
	
	// Aendern Sie nicht die Signaturen der bestehenden Methoden und Konstruktoren.
    // Sie duerfen weitere Methoden, Felder, und Konstruktoren zu der Klasse hinzufuegen.
	
	public Student(String firstName, String lastName) {
		// TODO: Implementieren Sie die Methode
	}
	
	public String firstName() {
		// TODO: Implementieren Sie die Methode
		return null;
	}
	
	public String lastName() {
		// TODO: Implementieren Sie die Methode
		return null;
	}
	
	public void givePoints(int points) {
		// TODO: Implementieren Sie die Methode
	}
}
