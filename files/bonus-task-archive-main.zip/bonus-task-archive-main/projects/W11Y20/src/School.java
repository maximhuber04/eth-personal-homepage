public class School {
	
	// Aendern Sie nicht die Signaturen der bestehenden Methoden.
    // Sie duerfen weitere Methoden, Felder, und Konstruktoren zu der Klasse hinzufuegen.
	
	public House createHouse(String name) {
		// TODO: Implementieren Sie die Methode
		return null;
	}
	
	public House winner() {
		// TODO: Implementieren Sie die Methode
		return null;
	}
	
	public int points() {
		// TODO: Implementieren Sie die Methode
		return -1;
	}
}
