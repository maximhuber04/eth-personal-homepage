
/**
 * A box that contains an integer value
 */
public class IntBox {
    
    int value;
    
    public IntBox(int value) {
        this.value = value;
    }
}
